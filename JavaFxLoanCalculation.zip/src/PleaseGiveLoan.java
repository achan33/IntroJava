import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class PleaseGiveLoan extends Application {
	// Text Field
	private TextField aRate = new TextField();
	private TextField nYears = new TextField();
	private TextField amount = new TextField();
	private TextField mPay = new TextField();
	private TextField tPay = new TextField();

	public void start(Stage lStage) {
		lStage.setTitle("Loan Calculator");
		GridPane rootNode = new GridPane();
		Scene myScene = new Scene(rootNode, 300, 300);
		rootNode.setPadding(new Insets(30));
		rootNode.setHgap(10);
		rootNode.setVgap(10);
		rootNode.setAlignment(Pos.CENTER);

		// Label
		Label aIRate = new Label("Annual Interest Rate:");
		Label numYears = new Label("Number of Years:");
		Label amt = new Label("Loan Amount");
		Label monthPay = new Label("Montly Payment:");
		Label totalPay = new Label("Total Payment:");

		// adding to layout
		rootNode.add(aIRate, 0, 0);
		rootNode.add(numYears, 0, 1);
		rootNode.add(amt, 0, 2);
		rootNode.add(monthPay, 0, 3);
		rootNode.add(totalPay, 0, 4);

		// set values to unchangeable
		mPay.setEditable(false);
		tPay.setEditable(false);

		// adding to layout
		rootNode.add(aRate, 1, 0);
		rootNode.add(nYears, 1, 1);
		rootNode.add(amount, 1, 2);
		rootNode.add(mPay, 1, 3);
		rootNode.add(tPay, 1, 4);

		// (i*A)/(1-(1+i)^-n) <--month rate
		// i= periodic interest rate A. amount of loan, n=number of compound periods
		// (12)
		Button calc = new Button("Calculate");
		rootNode.add(calc, 1, 5);
		rootNode.setAlignment(Pos.BASELINE_RIGHT);

		calc.setOnAction(new CalcHandler());

		lStage.setScene(myScene);
		lStage.show();

	}

	class CalcHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			// getting values from user input
			double loanAmt = Double.parseDouble(amount.getText());
			double interestRate = Double.parseDouble(aRate.getText());
			double numYears = Double.parseDouble(nYears.getText());

			// defining formula values
			double n = numYears * 12;
			double i = (interestRate / 100) / 12;

			String monthPay = "" + (i * loanAmt) / (1 - Math.pow(1 + i, -n));
			String totalPay = "" + (Double.parseDouble(monthPay) * n);

			mPay.setText(monthPay);
			tPay.setText(totalPay);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

}
